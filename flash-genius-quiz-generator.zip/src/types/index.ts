export type QuizMode = 'flashcard' | 'multiple-choice' | 'true-false' | 'fill-blank' | 'matching' | 'rapid-fire';

export interface Flashcard {
  id: string;
  front: string;
  back: string;
}

export interface MultipleChoiceQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
}

export interface TrueFalseQuestion {
  id: string;
  statement: string;
  isTrue: boolean;
  explanation?: string;
}

export interface FillBlankQuestion {
  id: string;
  sentence: string;
  blanks: string[];
  hint?: string;
}

export interface MatchingPair {
  id: string;
  term: string;
  definition: string;
}

export interface QuizSet {
  id: string;
  title: string;
  description: string;
  createdAt: number;
  flashcards: Flashcard[];
  multipleChoice: MultipleChoiceQuestion[];
  trueFalse: TrueFalseQuestion[];
  fillBlank: FillBlankQuestion[];
  matching: MatchingPair[];
  sourceText: string;
}

export interface StreakData {
  currentStreak: number;
  longestStreak: number;
  lastStudyDate: string;
  totalSessions: number;
  totalCorrect: number;
  totalAnswered: number;
  dailyGoal: number;
  todayCount: number;
}

export interface QuizResult {
  quizSetId: string;
  mode: QuizMode;
  score: number;
  total: number;
  date: number;
}
