
import { Flame, Trophy, Target, Zap } from 'lucide-react';
import { StreakData } from '../types';

interface Props {
  streak: StreakData;
}

export default function StreakBadge({ streak }: Props) {
  const accuracy = streak.totalAnswered > 0
    ? Math.round((streak.totalCorrect / streak.totalAnswered) * 100)
    : 0;

  const goalProgress = Math.min((streak.todayCount / streak.dailyGoal) * 100, 100);

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {/* Current Streak */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-500/30 p-4">
        <div className="absolute top-0 right-0 w-16 h-16 bg-orange-500/10 rounded-full -translate-y-4 translate-x-4" />
        <Flame className="text-orange-400 mb-2" size={20} />
        <div className="text-2xl font-bold text-white">{streak.currentStreak}</div>
        <div className="text-xs text-gray-400 mt-0.5">Day Streak</div>
      </div>

      {/* Longest Streak */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-yellow-500/20 to-amber-500/20 border border-yellow-500/30 p-4">
        <div className="absolute top-0 right-0 w-16 h-16 bg-yellow-500/10 rounded-full -translate-y-4 translate-x-4" />
        <Trophy className="text-yellow-400 mb-2" size={20} />
        <div className="text-2xl font-bold text-white">{streak.longestStreak}</div>
        <div className="text-xs text-gray-400 mt-0.5">Best Streak</div>
      </div>

      {/* Accuracy */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 p-4">
        <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/10 rounded-full -translate-y-4 translate-x-4" />
        <Zap className="text-emerald-400 mb-2" size={20} />
        <div className="text-2xl font-bold text-white">{accuracy}%</div>
        <div className="text-xs text-gray-400 mt-0.5">Accuracy</div>
      </div>

      {/* Daily Goal */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-500/20 to-purple-500/20 border border-violet-500/30 p-4">
        <div className="absolute top-0 right-0 w-16 h-16 bg-violet-500/10 rounded-full -translate-y-4 translate-x-4" />
        <Target className="text-violet-400 mb-2" size={20} />
        <div className="text-2xl font-bold text-white">{streak.todayCount}/{streak.dailyGoal}</div>
        <div className="text-xs text-gray-400 mt-0.5">Today's Goal</div>
        <div className="mt-2 h-1 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-violet-500 to-purple-400 rounded-full transition-all duration-500"
            style={{ width: `${goalProgress}%` }}
          />
        </div>
      </div>
    </div>
  );
}
