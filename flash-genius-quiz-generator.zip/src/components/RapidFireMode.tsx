import { useState, useEffect, useRef } from 'react';
import { Timer, Zap, RotateCcw } from 'lucide-react';
import { MultipleChoiceQuestion } from '../types';

interface Props {
  questions: MultipleChoiceQuestion[];
  onComplete: (correct: number, total: number) => void;
}

const TIME_PER_QUESTION = 8;

export default function RapidFireMode({ questions, onComplete }: Props) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(TIME_PER_QUESTION);
  const [selected, setSelected] = useState<number | null>(null);
  const [correct, setCorrect] = useState(0);
  const [done, setDone] = useState(false);
  const [results, setResults] = useState<boolean[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const current = questions[currentIdx];

  const nextQuestion = (wasCorrect: boolean) => {
    setResults(r => [...r, wasCorrect]);
    if (currentIdx + 1 >= questions.length) {
      setDone(true);
      onComplete(correct + (wasCorrect ? 1 : 0), questions.length);
      return;
    }
    setCurrentIdx(i => i + 1);
    setTimeLeft(TIME_PER_QUESTION);
    setSelected(null);
  };

  useEffect(() => {
    if (done || selected !== null) return;
    timerRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          clearInterval(timerRef.current!);
          nextQuestion(false);
          return TIME_PER_QUESTION;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [currentIdx, done, selected]);

  const handleSelect = (idx: number) => {
    if (selected !== null) return;
    clearInterval(timerRef.current!);
    setSelected(idx);
    const isCorrect = idx === current.correctIndex;
    if (isCorrect) setCorrect(c => c + 1);
    setTimeout(() => nextQuestion(isCorrect), 600);
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setTimeLeft(TIME_PER_QUESTION);
    setSelected(null);
    setCorrect(0);
    setDone(false);
    setResults([]);
  };

  if (done) {
    const pct = Math.round((correct / questions.length) * 100);
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-6">
        <div className="text-6xl">⚡</div>
        <div className="text-center">
          <h3 className="text-2xl font-bold text-white mb-2">Rapid Fire Complete!</h3>
          <p className="text-gray-400">{correct}/{questions.length} correct</p>
        </div>
        <div className="flex gap-1 flex-wrap justify-center max-w-xs">
          {results.map((r, i) => (
            <div key={i} className={`w-5 h-5 rounded text-xs flex items-center justify-center font-bold ${r ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'}`}>
              {r ? '✓' : '✗'}
            </div>
          ))}
        </div>
        <div className="text-4xl font-bold text-white">{pct}%</div>
        <button onClick={handleRestart} className="btn-primary flex items-center gap-2">
          <RotateCcw size={16} /> Play Again
        </button>
      </div>
    );
  }

  if (!current) return null;

  const timerPct = (timeLeft / TIME_PER_QUESTION) * 100;
  const timerColor = timeLeft <= 3 ? '#ef4444' : timeLeft <= 5 ? '#f59e0b' : '#10b981';

  return (
    <div className="flex flex-col gap-5">
      {/* Timer Bar */}
      <div className="flex items-center gap-3">
        <Timer size={18} className={timeLeft <= 3 ? 'text-red-400 animate-pulse' : 'text-emerald-400'} />
        <div className="flex-1 h-3 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-1000 ease-linear"
            style={{ width: `${timerPct}%`, backgroundColor: timerColor }}
          />
        </div>
        <span className={`font-bold text-lg tabular-nums ${timeLeft <= 3 ? 'text-red-400' : 'text-white'}`}>
          {timeLeft}s
        </span>
      </div>

      {/* Score */}
      <div className="flex items-center justify-between text-sm">
        <span className="text-gray-400">{currentIdx + 1}/{questions.length}</span>
        <div className="flex items-center gap-1.5 text-yellow-400 font-bold">
          <Zap size={16} className="fill-yellow-400" />
          {correct} pts
        </div>
      </div>

      {/* Question */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 p-5">
        <div className="text-xs font-semibold text-orange-400 uppercase tracking-widest mb-3">⚡ Rapid Fire</div>
        <p className="text-white font-semibold text-lg leading-relaxed">{current.question}</p>
      </div>

      {/* Options */}
      <div className="grid grid-cols-2 gap-3">
        {current.options.map((opt, idx) => {
          let cls = 'bg-white/5 border-white/20 text-gray-200 hover:bg-white/10 hover:border-white/40 cursor-pointer';
          if (selected !== null) {
            if (idx === current.correctIndex) cls = 'bg-emerald-500/30 border-emerald-400 text-emerald-100';
            else if (idx === selected) cls = 'bg-red-500/20 border-red-400 text-red-200';
            else cls = 'bg-white/5 border-white/10 text-gray-500 opacity-40';
          }
          return (
            <button
              key={idx}
              onClick={() => handleSelect(idx)}
              disabled={selected !== null}
              className={`p-3 rounded-xl border text-sm text-left transition-all duration-200 ${cls}`}
            >
              <span className="font-bold text-xs opacity-60 mr-2">{['A','B','C','D'][idx]}</span>
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}
