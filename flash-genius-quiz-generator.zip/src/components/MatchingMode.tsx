import { useState } from 'react';
import { RotateCcw, CheckCircle2 } from 'lucide-react';
import { MatchingPair } from '../types';

interface Props {
  pairs: MatchingPair[];
  onComplete: (correct: number, total: number) => void;
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function MatchingMode({ pairs, onComplete }: Props) {
  const limited = pairs.slice(0, 8);
  const [shuffledDefs, setShuffledDefs] = useState(() => shuffle(limited.map((p, i) => ({ ...p, origIdx: i }))));
  const [selectedTerm, setSelectedTerm] = useState<number | null>(null);
  const [selectedDef, setSelectedDef] = useState<number | null>(null);
  const [matched, setMatched] = useState<Set<string>>(new Set());
  const [incorrect, setIncorrect] = useState<Set<number>>(new Set());
  const [done, setDone] = useState(false);
  const [attempts, setAttempts] = useState(0);

  const handleTermClick = (idx: number) => {
    if (matched.has(limited[idx].id)) return;
    setSelectedTerm(idx);
    setSelectedDef(null);
    setIncorrect(new Set());
  };

  const handleDefClick = (idx: number) => {
    if (matched.has(shuffledDefs[idx].id)) return;
    if (selectedTerm === null) return;

    setAttempts(a => a + 1);

    if (shuffledDefs[idx].id === limited[selectedTerm].id) {
      const newMatched = new Set(matched);
      newMatched.add(limited[selectedTerm].id);
      setMatched(newMatched);
      setSelectedTerm(null);
      setSelectedDef(null);

      if (newMatched.size === limited.length) {
        setDone(true);
        onComplete(limited.length, limited.length);
      }
    } else {
      setIncorrect(new Set([selectedTerm, idx]));
      setSelectedDef(idx);
      setTimeout(() => {
        setIncorrect(new Set());
        setSelectedTerm(null);
        setSelectedDef(null);
      }, 800);
    }
  };

  const handleRestart = () => {
    setShuffledDefs(shuffle(limited.map((p, i) => ({ ...p, origIdx: i }))));
    setSelectedTerm(null);
    setSelectedDef(null);
    setMatched(new Set());
    setIncorrect(new Set());
    setDone(false);
    setAttempts(0);
  };

  if (done) {
    const efficiency = Math.max(0, Math.round(((limited.length / attempts) * 100)));
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-6">
        <div className="text-6xl">🎯</div>
        <div className="text-center">
          <h3 className="text-2xl font-bold text-white mb-2">All Matched!</h3>
          <p className="text-gray-400">Completed in {attempts} attempts</p>
        </div>
        <div className="text-3xl font-bold text-white">{efficiency}% Efficiency</div>
        <button onClick={handleRestart} className="btn-primary flex items-center gap-2">
          <RotateCcw size={16} /> Play Again
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div className="text-sm text-gray-400">{matched.size}/{limited.length} matched</div>
        <div className="flex gap-2">
          {Array.from({ length: limited.length }).map((_, i) => (
            <div key={i} className={`w-2 h-2 rounded-full transition-all ${i < matched.size ? 'bg-emerald-400' : 'bg-white/20'}`} />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Terms */}
        <div className="flex flex-col gap-2">
          <div className="text-xs font-semibold text-violet-400 uppercase tracking-widest mb-1 text-center">Terms</div>
          {limited.map((pair, idx) => (
            <button
              key={pair.id}
              onClick={() => handleTermClick(idx)}
              disabled={matched.has(pair.id)}
              className={`
                p-3 rounded-xl text-sm font-medium text-left transition-all duration-200
                ${matched.has(pair.id)
                  ? 'bg-emerald-500/20 border-2 border-emerald-500/50 text-emerald-300 opacity-60 cursor-default'
                  : selectedTerm === idx
                    ? 'bg-violet-500/30 border-2 border-violet-400 text-white scale-[1.02]'
                    : 'bg-white/5 border-2 border-white/10 text-gray-300 hover:border-violet-400/60 hover:bg-violet-500/10 cursor-pointer'}
              `}
            >
              {matched.has(pair.id) && <CheckCircle2 className="inline mr-1 mb-0.5 text-emerald-400" size={12} />}
              {pair.term}
            </button>
          ))}
        </div>

        {/* Definitions */}
        <div className="flex flex-col gap-2">
          <div className="text-xs font-semibold text-blue-400 uppercase tracking-widest mb-1 text-center">Definitions</div>
          {shuffledDefs.map((pair, idx) => (
            <button
              key={pair.id + '-def-' + idx}
              onClick={() => handleDefClick(idx)}
              disabled={matched.has(pair.id) || selectedTerm === null}
              className={`
                p-3 rounded-xl text-xs text-left transition-all duration-200
                ${matched.has(pair.id)
                  ? 'bg-emerald-500/20 border-2 border-emerald-500/50 text-emerald-300 opacity-60 cursor-default'
                  : incorrect.has(idx)
                    ? 'bg-red-500/20 border-2 border-red-400 text-red-200 animate-pulse'
                    : selectedDef === idx
                      ? 'bg-blue-500/30 border-2 border-blue-400 text-white'
                      : selectedTerm !== null
                        ? 'bg-white/5 border-2 border-white/10 text-gray-300 hover:border-blue-400/60 hover:bg-blue-500/10 cursor-pointer'
                        : 'bg-white/5 border-2 border-white/10 text-gray-400 cursor-not-allowed opacity-60'}
              `}
            >
              {pair.definition}
            </button>
          ))}
        </div>
      </div>

      {selectedTerm !== null && (
        <p className="text-center text-sm text-violet-400 animate-pulse">
          Now click a matching definition →
        </p>
      )}
    </div>
  );
}
