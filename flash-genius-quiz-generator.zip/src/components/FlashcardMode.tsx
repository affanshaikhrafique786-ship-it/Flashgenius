import { useState } from 'react';
import { ChevronLeft, ChevronRight, RotateCcw, ThumbsUp, ThumbsDown, Shuffle } from 'lucide-react';
import { Flashcard } from '../types';

interface Props {
  cards: Flashcard[];
  onComplete: (correct: number, total: number) => void;
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function FlashcardMode({ cards, onComplete }: Props) {
  const [deck, setDeck] = useState(cards);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [correct, setCorrect] = useState(0);
  const [answered, setAnswered] = useState(0);
  const [done, setDone] = useState(false);
  const [swipeDir, setSwipeDir] = useState<'left' | 'right' | null>(null);

  const current = deck[currentIdx];

  const handleAnswer = (knew: boolean) => {
    if (!isFlipped) return;
    setSwipeDir(knew ? 'right' : 'left');
    setTimeout(() => {
      if (knew) setCorrect(c => c + 1);
      setAnswered(a => a + 1);
      if (currentIdx + 1 >= deck.length) {
        setDone(true);
        onComplete(knew ? correct + 1 : correct, deck.length);
      } else {
        setCurrentIdx(i => i + 1);
        setIsFlipped(false);
      }
      setSwipeDir(null);
    }, 300);
  };

  const handleShuffle = () => {
    setDeck(shuffle(deck));
    setCurrentIdx(0);
    setIsFlipped(false);
    setCorrect(0);
    setAnswered(0);
    setDone(false);
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setIsFlipped(false);
    setCorrect(0);
    setAnswered(0);
    setDone(false);
  };

  if (done) {
    const pct = Math.round((correct / deck.length) * 100);
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-6">
        <div className="text-6xl">{pct >= 80 ? '🎉' : pct >= 60 ? '👍' : '💪'}</div>
        <div className="text-center">
          <h3 className="text-2xl font-bold text-white mb-2">Session Complete!</h3>
          <p className="text-gray-400">You knew {correct} out of {deck.length} cards</p>
        </div>
        <div className="w-48 h-48 relative">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="8" />
            <circle
              cx="50" cy="50" r="40" fill="none"
              stroke={pct >= 80 ? '#10b981' : pct >= 60 ? '#f59e0b' : '#ef4444'}
              strokeWidth="8"
              strokeDasharray={`${(pct / 100) * 251.2} 251.2`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold text-white">{pct}%</span>
            <span className="text-xs text-gray-400">Score</span>
          </div>
        </div>
        <div className="flex gap-3">
          <button onClick={handleRestart} className="btn-secondary flex items-center gap-2">
            <RotateCcw size={16} /> Restart
          </button>
          <button onClick={handleShuffle} className="btn-primary flex items-center gap-2">
            <Shuffle size={16} /> Shuffle & Retry
          </button>
        </div>
      </div>
    );
  }

  if (!current) return null;

  return (
    <div className="flex flex-col items-center gap-6">
      {/* Progress */}
      <div className="w-full flex items-center gap-3">
        <span className="text-sm text-gray-400">{currentIdx + 1}/{deck.length}</span>
        <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-violet-500 to-blue-500 rounded-full transition-all duration-300"
            style={{ width: `${((currentIdx) / deck.length) * 100}%` }}
          />
        </div>
        <button onClick={handleShuffle} className="text-gray-400 hover:text-white transition-colors">
          <Shuffle size={16} />
        </button>
      </div>

      {/* Card */}
      <div
        className={`
          relative w-full max-w-lg cursor-pointer select-none
          transition-transform duration-300
          ${swipeDir === 'right' ? 'translate-x-20 opacity-0' : ''}
          ${swipeDir === 'left' ? '-translate-x-20 opacity-0' : ''}
        `}
        style={{ perspective: '1000px' }}
        onClick={() => setIsFlipped(f => !f)}
      >
        <div
          className="relative w-full transition-all duration-500"
          style={{
            transformStyle: 'preserve-3d',
            transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
            minHeight: 240,
          }}
        >
          {/* Front */}
          <div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 p-8 flex flex-col items-center justify-center"
            style={{ backfaceVisibility: 'hidden' }}
          >
            <div className="text-xs font-semibold text-violet-400 uppercase tracking-widest mb-4">Question</div>
            <p className="text-white text-xl font-semibold text-center leading-relaxed">{current.front}</p>
            <div className="mt-6 flex items-center gap-1.5 text-gray-500 text-xs">
              <RotateCcw size={12} /> Click to reveal answer
            </div>
          </div>

          {/* Back */}
          <div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-violet-900/60 to-blue-900/60 border border-violet-500/30 p-8 flex flex-col items-center justify-center"
            style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
          >
            <div className="text-xs font-semibold text-emerald-400 uppercase tracking-widest mb-4">Answer</div>
            <p className="text-white text-lg font-medium text-center leading-relaxed">{current.back}</p>
          </div>
        </div>
      </div>

      {/* Actions */}
      {isFlipped ? (
        <div className="flex gap-4">
          <button
            onClick={() => handleAnswer(false)}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-red-500/20 border border-red-500/40 text-red-300 hover:bg-red-500/30 transition-all font-semibold"
          >
            <ThumbsDown size={18} /> Didn't Know
          </button>
          <button
            onClick={() => handleAnswer(true)}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30 transition-all font-semibold"
          >
            <ThumbsUp size={18} /> Got It!
          </button>
        </div>
      ) : (
        <div className="flex gap-4">
          <button
            onClick={() => setCurrentIdx(i => Math.max(0, i - 1))}
            disabled={currentIdx === 0}
            className="p-3 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 disabled:opacity-30 transition-all"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={() => setIsFlipped(f => !f)}
            className="px-8 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 text-white font-semibold hover:opacity-90 transition-all"
          >
            Flip Card
          </button>
          <button
            onClick={() => { setCurrentIdx(i => Math.min(deck.length - 1, i + 1)); setIsFlipped(false); }}
            disabled={currentIdx === deck.length - 1}
            className="p-3 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 disabled:opacity-30 transition-all"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      )}

      {/* Stats */}
      <div className="flex gap-6 text-sm">
        <span className="text-emerald-400">✓ {correct} knew</span>
        <span className="text-red-400">✗ {answered - correct} missed</span>
        <span className="text-gray-400">{deck.length - answered} remaining</span>
      </div>
    </div>
  );
}
