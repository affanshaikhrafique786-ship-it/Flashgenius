import { useState } from 'react';
import { CheckCircle2, XCircle, ChevronRight, RotateCcw } from 'lucide-react';
import { FillBlankQuestion } from '../types';

interface Props {
  questions: FillBlankQuestion[];
  onComplete: (correct: number, total: number) => void;
}

export default function FillBlankMode({ questions, onComplete }: Props) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [inputs, setInputs] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [correct, setCorrect] = useState(0);
  const [done, setDone] = useState(false);

  const current = questions[currentIdx];

  const initInputs = (q: FillBlankQuestion) => new Array(q.blanks.length).fill('');

  useState(() => {
    if (current) setInputs(initInputs(current));
  });

  const handleSubmit = () => {
    if (!submitted) {
      setSubmitted(true);
      let thisCorrect = 0;
      for (let i = 0; i < current.blanks.length; i++) {
        if (inputs[i]?.trim().toLowerCase() === current.blanks[i]?.toLowerCase()) {
          thisCorrect++;
        }
      }
      if (thisCorrect === current.blanks.length) {
        setCorrect(c => c + 1);
      }
    }
  };

  const handleNext = () => {
    if (currentIdx + 1 >= questions.length) {
      setDone(true);
      onComplete(correct, questions.length);
    } else {
      const next = questions[currentIdx + 1];
      setCurrentIdx(i => i + 1);
      setInputs(initInputs(next));
      setSubmitted(false);
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setInputs(initInputs(questions[0]));
    setSubmitted(false);
    setCorrect(0);
    setDone(false);
  };

  if (done) {
    const pct = Math.round((correct / questions.length) * 100);
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-6">
        <div className="text-6xl">{pct >= 80 ? '✏️🌟' : pct >= 60 ? '✏️👍' : '📝'}</div>
        <div className="text-center">
          <h3 className="text-2xl font-bold text-white mb-2">Complete!</h3>
          <p className="text-gray-400">{correct}/{questions.length} fully correct</p>
        </div>
        <div className="text-5xl font-bold text-white">{pct}%</div>
        <button onClick={handleRestart} className="btn-primary flex items-center gap-2">
          <RotateCcw size={16} /> Try Again
        </button>
      </div>
    );
  }

  if (!current) return null;

  const parts = current.sentence.split('______');

  return (
    <div className="flex flex-col gap-6">
      {/* Progress */}
      <div className="flex items-center gap-3">
        <span className="text-sm text-gray-400">{currentIdx + 1}/{questions.length}</span>
        <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-pink-500 to-rose-500 rounded-full transition-all"
            style={{ width: `${(currentIdx / questions.length) * 100}%` }}
          />
        </div>
        <span className="text-sm text-emerald-400">{correct} ✓</span>
      </div>

      {/* Card */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 p-6">
        <div className="text-xs font-semibold text-pink-400 uppercase tracking-widest mb-4">
          Fill in the Blank{current.blanks.length > 1 ? 's' : ''}
        </div>
        {current.hint && (
          <p className="text-xs text-gray-500 mb-4">Hint: {current.hint}</p>
        )}
        <div className="flex flex-wrap items-baseline gap-x-1.5 gap-y-3 text-white text-lg leading-loose">
          {parts.map((part, idx) => (
            <span key={idx} className="flex flex-wrap items-baseline gap-x-1.5">
              <span>{part}</span>
              {idx < current.blanks.length && (
                <span className="inline-flex flex-col items-center">
                  <input
                    type="text"
                    value={inputs[idx] || ''}
                    onChange={e => {
                      const newInputs = [...inputs];
                      newInputs[idx] = e.target.value;
                      setInputs(newInputs);
                    }}
                    disabled={submitted}
                    onKeyDown={e => e.key === 'Enter' && !submitted && handleSubmit()}
                    className={`
                      border-b-2 bg-transparent text-center font-semibold outline-none px-1 min-w-[80px] transition-colors
                      ${submitted
                        ? inputs[idx]?.trim().toLowerCase() === current.blanks[idx]?.toLowerCase()
                          ? 'border-emerald-400 text-emerald-300'
                          : 'border-red-400 text-red-300'
                        : 'border-pink-500/60 focus:border-pink-400 text-pink-100'}
                    `}
                    placeholder="___"
                    style={{ width: `${Math.max(80, (current.blanks[idx]?.length || 5) * 12)}px` }}
                  />
                  {submitted && inputs[idx]?.trim().toLowerCase() !== current.blanks[idx]?.toLowerCase() && (
                    <span className="text-xs text-emerald-400 mt-1">→ {current.blanks[idx]}</span>
                  )}
                </span>
              )}
            </span>
          ))}
        </div>
      </div>

      {/* Actions */}
      {!submitted ? (
        <div className="flex justify-end">
          <button
            onClick={handleSubmit}
            disabled={inputs.some(i => !i.trim())}
            className="btn-primary disabled:opacity-50"
          >
            Check Answer
          </button>
        </div>
      ) : (
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            {inputs.every((inp, i) => inp.trim().toLowerCase() === current.blanks[i]?.toLowerCase())
              ? <><CheckCircle2 className="text-emerald-400" size={20} /><span className="text-emerald-400 font-semibold">Perfect!</span></>
              : <><XCircle className="text-red-400" size={20} /><span className="text-red-400 font-semibold">Keep going!</span></>
            }
          </div>
          <button onClick={handleNext} className="btn-primary flex items-center gap-2">
            {currentIdx + 1 >= questions.length ? 'See Results' : 'Next'}
            <ChevronRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
