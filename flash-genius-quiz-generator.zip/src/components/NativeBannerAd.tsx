import { useEffect, useRef } from 'react';

export default function NativeBannerAd() {
  const containerRef = useRef<HTMLDivElement>(null);
  const loaded = useRef(false);

  useEffect(() => {
    if (loaded.current) return;
    loaded.current = true;

    const script = document.createElement('script');
    script.async = true;
    script.setAttribute('data-cfasync', 'false');
    script.src = 'https://pl29729707.effectivecpmnetwork.com/360e28a674a2ba6cc0ab95e9e906540f/invoke.js';
    
    if (containerRef.current) {
      containerRef.current.appendChild(script);
    }
  }, []);

  return (
    <div className="w-full my-4 flex justify-center">
      <div ref={containerRef} className="w-full max-w-3xl">
        <div id="container-360e28a674a2ba6cc0ab95e9e906540f" />
      </div>
    </div>
  );
}
