import { useState } from 'react';
import { CheckCircle2, XCircle, RotateCcw, ChevronRight } from 'lucide-react';
import { TrueFalseQuestion } from '../types';

interface Props {
  questions: TrueFalseQuestion[];
  onComplete: (correct: number, total: number) => void;
}

export default function TrueFalseMode({ questions, onComplete }: Props) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selected, setSelected] = useState<boolean | null>(null);
  const [correct, setCorrect] = useState(0);
  const [done, setDone] = useState(false);
  const [history, setHistory] = useState<boolean[]>([]);

  const current = questions[currentIdx];

  const handleAnswer = (answer: boolean) => {
    if (selected !== null) return;
    setSelected(answer);
    const isCorrect = answer === current.isTrue;
    if (isCorrect) setCorrect(c => c + 1);
    setHistory(h => [...h, isCorrect]);
  };

  const handleNext = () => {
    if (currentIdx + 1 >= questions.length) {
      setDone(true);
      onComplete(correct, questions.length);
    } else {
      setCurrentIdx(i => i + 1);
      setSelected(null);
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setSelected(null);
    setCorrect(0);
    setDone(false);
    setHistory([]);
  };

  if (done) {
    const pct = Math.round((correct / questions.length) * 100);
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-6">
        <div className="text-6xl">{pct >= 80 ? '🎯' : pct >= 60 ? '👏' : '🔄'}</div>
        <div className="text-center">
          <h3 className="text-2xl font-bold text-white mb-2">Quiz Complete!</h3>
          <p className="text-gray-400">{correct}/{questions.length} correct</p>
        </div>
        <div className="flex gap-2 flex-wrap justify-center max-w-xs">
          {history.map((h, i) => (
            <div key={i} className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${h ? 'bg-emerald-500' : 'bg-red-500'}`}>
              {h ? '✓' : '✗'}
            </div>
          ))}
        </div>
        <div className="text-3xl font-bold text-white">{pct}%</div>
        <button onClick={handleRestart} className="btn-primary flex items-center gap-2">
          <RotateCcw size={16} /> Try Again
        </button>
      </div>
    );
  }

  if (!current) return null;

  return (
    <div className="flex flex-col gap-6">
      {/* Progress */}
      <div className="flex items-center gap-3">
        <span className="text-sm text-gray-400">{currentIdx + 1}/{questions.length}</span>
        <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-teal-500 to-emerald-500 rounded-full transition-all duration-300"
            style={{ width: `${(currentIdx / questions.length) * 100}%` }}
          />
        </div>
        <div className="flex gap-1">
          {history.slice(-5).map((h, i) => (
            <div key={i} className={`w-2 h-2 rounded-full ${h ? 'bg-emerald-400' : 'bg-red-400'}`} />
          ))}
        </div>
      </div>

      {/* Statement Card */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 p-8">
        <div className="text-xs font-semibold text-teal-400 uppercase tracking-widest mb-4 text-center">
          True or False?
        </div>
        <p className="text-white text-xl font-semibold text-center leading-relaxed">{current.statement}</p>
      </div>

      {/* Buttons */}
      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={() => handleAnswer(true)}
          disabled={selected !== null}
          className={`
            py-6 rounded-2xl font-bold text-xl flex flex-col items-center gap-2 transition-all duration-300
            ${selected === null ? 'bg-gradient-to-br from-emerald-600/30 to-teal-600/30 border-2 border-emerald-500/50 text-emerald-300 hover:from-emerald-600/50 hover:to-teal-600/50 hover:scale-105 cursor-pointer' :
              selected === true
                ? current.isTrue === true
                  ? 'bg-emerald-500/30 border-2 border-emerald-400 text-emerald-100 scale-105'
                  : 'bg-red-500/20 border-2 border-red-400/50 text-red-300 opacity-70'
                : current.isTrue === true
                  ? 'bg-emerald-500/30 border-2 border-emerald-400 text-emerald-100 animate-pulse'
                  : 'opacity-30 bg-white/5 border-2 border-white/10 text-gray-400'}
          `}
        >
          <CheckCircle2 size={32} />
          TRUE
        </button>

        <button
          onClick={() => handleAnswer(false)}
          disabled={selected !== null}
          className={`
            py-6 rounded-2xl font-bold text-xl flex flex-col items-center gap-2 transition-all duration-300
            ${selected === null ? 'bg-gradient-to-br from-red-600/30 to-rose-600/30 border-2 border-red-500/50 text-red-300 hover:from-red-600/50 hover:to-rose-600/50 hover:scale-105 cursor-pointer' :
              selected === false
                ? current.isTrue === false
                  ? 'bg-emerald-500/30 border-2 border-emerald-400 text-emerald-100 scale-105'
                  : 'bg-red-500/20 border-2 border-red-400/50 text-red-300 opacity-70'
                : current.isTrue === false
                  ? 'bg-emerald-500/30 border-2 border-emerald-400 text-emerald-100 animate-pulse'
                  : 'opacity-30 bg-white/5 border-2 border-white/10 text-gray-400'}
          `}
        >
          <XCircle size={32} />
          FALSE
        </button>
      </div>

      {/* Result */}
      {selected !== null && (
        <div className="flex flex-col gap-3">
          <div className={`text-center text-lg font-bold ${selected === current.isTrue ? 'text-emerald-400' : 'text-red-400'}`}>
            {selected === current.isTrue ? '✓ Correct!' : `✗ The answer was ${current.isTrue ? 'TRUE' : 'FALSE'}`}
          </div>

          {current.explanation && (
            <div className="rounded-xl bg-blue-500/10 border border-blue-500/30 p-3">
              <p className="text-blue-200 text-sm leading-relaxed">{current.explanation}</p>
            </div>
          )}

          <div className="flex justify-end">
            <button onClick={handleNext} className="btn-primary flex items-center gap-2">
              {currentIdx + 1 >= questions.length ? 'See Results' : 'Next'}
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
