import { useState } from 'react';
import { CheckCircle2, XCircle, ChevronRight, RotateCcw, Lightbulb } from 'lucide-react';
import { MultipleChoiceQuestion } from '../types';

interface Props {
  questions: MultipleChoiceQuestion[];
  onComplete: (correct: number, total: number) => void;
}

export default function MultipleChoiceMode({ questions, onComplete }: Props) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [correct, setCorrect] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [done, setDone] = useState(false);

  const current = questions[currentIdx];

  const handleSelect = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    if (idx === current.correctIndex) setCorrect(c => c + 1);
  };

  const handleNext = () => {
    if (currentIdx + 1 >= questions.length) {
      setDone(true);
      onComplete(
        selected === current.correctIndex ? correct : correct,
        questions.length
      );
    } else {
      setCurrentIdx(i => i + 1);
      setSelected(null);
      setShowExplanation(false);
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setSelected(null);
    setCorrect(0);
    setShowExplanation(false);
    setDone(false);
  };

  if (done) {
    const pct = Math.round((correct / questions.length) * 100);
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-6">
        <div className="text-6xl">{pct >= 80 ? '🏆' : pct >= 60 ? '⭐' : '📚'}</div>
        <div className="text-center">
          <h3 className="text-2xl font-bold text-white mb-2">Quiz Complete!</h3>
          <p className="text-gray-400">{correct}/{questions.length} correct answers</p>
        </div>
        <div className="w-48 h-48 relative">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="8" />
            <circle
              cx="50" cy="50" r="40" fill="none"
              stroke={pct >= 80 ? '#10b981' : pct >= 60 ? '#f59e0b' : '#ef4444'}
              strokeWidth="8"
              strokeDasharray={`${(pct / 100) * 251.2} 251.2`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold text-white">{pct}%</span>
            <span className="text-xs text-gray-400">Score</span>
          </div>
        </div>
        <button onClick={handleRestart} className="btn-primary flex items-center gap-2">
          <RotateCcw size={16} /> Try Again
        </button>
      </div>
    );
  }

  if (!current) return null;

  const optionColors = ['from-blue-600/20 to-cyan-600/20 border-blue-500/40', 'from-purple-600/20 to-violet-600/20 border-purple-500/40', 'from-pink-600/20 to-rose-600/20 border-pink-500/40', 'from-amber-600/20 to-orange-600/20 border-amber-500/40'];
  const optionLetters = ['A', 'B', 'C', 'D'];

  return (
    <div className="flex flex-col gap-6">
      {/* Progress */}
      <div className="flex items-center gap-3">
        <span className="text-sm text-gray-400">{currentIdx + 1}/{questions.length}</span>
        <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full transition-all duration-300"
            style={{ width: `${((currentIdx) / questions.length) * 100}%` }}
          />
        </div>
        <span className="text-sm text-emerald-400">{correct} ✓</span>
      </div>

      {/* Question */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 p-6">
        <div className="text-xs font-semibold text-blue-400 uppercase tracking-widest mb-3">
          Question {currentIdx + 1}
        </div>
        <p className="text-white text-lg font-semibold leading-relaxed">{current.question}</p>
      </div>

      {/* Options */}
      <div className="grid grid-cols-1 gap-3">
        {current.options.map((option, idx) => {
          let state: 'default' | 'correct' | 'wrong' | 'missed' = 'default';
          if (selected !== null) {
            if (idx === current.correctIndex) state = 'correct';
            else if (idx === selected) state = 'wrong';
          }

          return (
            <button
              key={idx}
              onClick={() => handleSelect(idx)}
              disabled={selected !== null}
              className={`
                w-full text-left p-4 rounded-xl border flex items-start gap-3 transition-all duration-300
                ${state === 'correct' ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-100' :
                  state === 'wrong' ? 'bg-red-500/20 border-red-500/60 text-red-100' :
                  selected !== null ? `opacity-40 bg-gradient-to-r ${optionColors[idx % 4]}` :
                  `bg-gradient-to-r ${optionColors[idx % 4]} hover:brightness-125 cursor-pointer`}
                text-white
              `}
            >
              <span className={`
                shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold
                ${state === 'correct' ? 'bg-emerald-500 text-white' :
                  state === 'wrong' ? 'bg-red-500 text-white' :
                  'bg-white/10 text-gray-300'}
              `}>
                {state === 'correct' ? <CheckCircle2 size={16} /> :
                  state === 'wrong' ? <XCircle size={16} /> :
                  optionLetters[idx]}
              </span>
              <span className="leading-relaxed pt-0.5">{option}</span>
            </button>
          );
        })}
      </div>

      {/* Explanation */}
      {selected !== null && current.explanation && (
        <button
          onClick={() => setShowExplanation(s => !s)}
          className="flex items-center gap-2 text-amber-400 text-sm hover:text-amber-300 transition-colors"
        >
          <Lightbulb size={16} /> {showExplanation ? 'Hide' : 'Show'} Explanation
        </button>
      )}

      {showExplanation && current.explanation && (
        <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-4">
          <p className="text-amber-200 text-sm leading-relaxed">{current.explanation}</p>
        </div>
      )}

      {/* Next */}
      {selected !== null && (
        <div className="flex justify-between items-center">
          <span className={`font-semibold ${selected === current.correctIndex ? 'text-emerald-400' : 'text-red-400'}`}>
            {selected === current.correctIndex ? '✓ Correct!' : '✗ Incorrect'}
          </span>
          <button onClick={handleNext} className="btn-primary flex items-center gap-2">
            {currentIdx + 1 >= questions.length ? 'See Results' : 'Next Question'}
            <ChevronRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
