import { useState, useRef, useCallback } from 'react';
import { Upload, FileText, X, Loader2, File, FileType } from 'lucide-react';
import { processFile } from '../utils/pdfExtractor';

interface Props {
  onTextExtracted: (text: string, filename: string) => void;
}

const ACCEPTED_TYPES = ['.pdf', '.txt', '.docx', '.md', '.csv'];


function getFileIcon(name: string) {
  const ext = name.split('.').pop()?.toLowerCase();
  if (ext === 'pdf') return <FileType size={20} className="text-red-400" />;
  if (ext === 'docx') return <FileText size={20} className="text-blue-400" />;
  return <File size={20} className="text-green-400" />;
}

export default function FileUploader({ onTextExtracted }: Props) {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const processUpload = async (file: File) => {
    setSelectedFile(file);
    setError('');
    setIsProcessing(true);
    try {
      const text = await processFile(file);
      if (!text || text.trim().length < 50) {
        setError('Could not extract enough text from this file. Try another file or paste text manually.');
        return;
      }
      onTextExtracted(text, file.name.replace(/\.[^.]+$/, ''));
    } catch (err: any) {
      setError('Failed to process file: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) processUpload(file);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => setIsDragging(false), []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processUpload(file);
  };

  return (
    <div className="w-full">
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => inputRef.current?.click()}
        className={`
          relative rounded-2xl border-2 border-dashed cursor-pointer transition-all duration-300
          flex flex-col items-center justify-center p-8 min-h-[180px]
          ${isDragging
            ? 'border-violet-400 bg-violet-500/10 scale-[1.01]'
            : 'border-white/20 bg-white/5 hover:border-violet-400/60 hover:bg-violet-500/5'
          }
        `}
      >
        {isProcessing ? (
          <div className="flex flex-col items-center gap-3">
            <div className="relative">
              <Loader2 className="animate-spin text-violet-400" size={40} />
              <div className="absolute inset-0 animate-ping">
                <Loader2 className="text-violet-400/30" size={40} />
              </div>
            </div>
            <p className="text-gray-300 font-medium">Analyzing {selectedFile?.name}...</p>
            <p className="text-xs text-gray-500">Extracting content & generating questions</p>
          </div>
        ) : selectedFile && !error ? (
          <div className="flex flex-col items-center gap-2">
            {getFileIcon(selectedFile.name)}
            <p className="text-gray-300 font-medium">{selectedFile.name}</p>
            <p className="text-xs text-emerald-400">✓ Successfully processed</p>
            <button
              className="mt-2 text-xs text-gray-400 hover:text-white underline"
              onClick={e => { e.stopPropagation(); setSelectedFile(null); }}
            >
              Upload different file
            </button>
          </div>
        ) : (
          <>
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500/30 to-blue-500/30 border border-violet-500/30 flex items-center justify-center mb-4">
              <Upload className="text-violet-400" size={24} />
            </div>
            <p className="text-white font-semibold text-lg mb-1">Drop your file here</p>
            <p className="text-gray-400 text-sm mb-3">or click to browse</p>
            <div className="flex flex-wrap gap-2 justify-center">
              {ACCEPTED_TYPES.map(t => (
                <span key={t} className="text-xs px-2 py-0.5 rounded-full bg-white/10 text-gray-300 font-mono">
                  {t}
                </span>
              ))}
            </div>
          </>
        )}

        {error && (
          <div className="absolute bottom-3 left-3 right-3 bg-red-500/20 border border-red-500/40 rounded-xl p-3 flex items-start gap-2">
            <X size={14} className="text-red-400 mt-0.5 shrink-0" />
            <p className="text-red-300 text-xs">{error}</p>
          </div>
        )}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED_TYPES.join(',')}
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}
