import { useState, useEffect } from 'react';
import {
  Zap, BookOpen, Plus, Trash2, Play, Clock,
  BarChart3, Home, ChevronRight, Star, Flame, X, CheckCircle2,
  Upload, AlignLeft, Layers, RotateCcw, Award, PenTool, Shuffle
} from 'lucide-react';
import { QuizSet, QuizMode, StreakData } from './types';
import { generateQuizSet } from './utils/textParser';
import { saveQuizSet, getQuizSets, deleteQuizSet, getStreak, updateStreak, saveResult } from './utils/storage';
import FileUploader from './components/FileUploader';
import StreakBadge from './components/StreakBadge';
import FlashcardMode from './components/FlashcardMode';
import MultipleChoiceMode from './components/MultipleChoiceMode';
import TrueFalseMode from './components/TrueFalseMode';
import FillBlankMode from './components/FillBlankMode';
import MatchingMode from './components/MatchingMode';
import RapidFireMode from './components/RapidFireMode';
import NativeBannerAd from './components/NativeBannerAd';

type Page = 'home' | 'create' | 'library' | 'quiz' | 'stats';

const MODE_INFO: Record<QuizMode, { label: string; icon: React.ReactNode; color: string; desc: string }> = {
  flashcard: { label: 'Flashcards', icon: <RotateCcw size={18} />, color: 'from-violet-500 to-purple-600', desc: 'Flip cards to reveal answers' },
  'multiple-choice': { label: 'Multiple Choice', icon: <CheckCircle2 size={18} />, color: 'from-blue-500 to-cyan-600', desc: 'Choose from 4 options' },
  'true-false': { label: 'True / False', icon: <Layers size={18} />, color: 'from-teal-500 to-emerald-600', desc: 'Quick true or false questions' },
  'fill-blank': { label: 'Fill in the Blank', icon: <PenTool size={18} />, color: 'from-pink-500 to-rose-600', desc: 'Complete missing words' },
  matching: { label: 'Matching', icon: <Shuffle size={18} />, color: 'from-amber-500 to-orange-600', desc: 'Match terms to definitions' },
  'rapid-fire': { label: 'Rapid Fire', icon: <Zap size={18} />, color: 'from-red-500 to-orange-600', desc: '8 seconds per question!' },
};

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [quizSets, setQuizSets] = useState<QuizSet[]>([]);
  const [streak, setStreak] = useState<StreakData>(getStreak());
  const [activeSet, setActiveSet] = useState<QuizSet | null>(null);
  const [activeMode, setActiveMode] = useState<QuizMode>('flashcard');
  const [inputText, setInputText] = useState('');
  const [inputTitle, setInputTitle] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [toast, setToast] = useState('');
  const [inputTab, setInputTab] = useState<'text' | 'file'>('text');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  useEffect(() => {
    setQuizSets(getQuizSets());
  }, []);

  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(''), 3000);
      return () => clearTimeout(t);
    }
  }, [toast]);

  const showToast = (msg: string) => setToast(msg);

  const handleGenerate = async () => {
    if (inputText.trim().length < 50) {
      showToast('Please provide more text (at least 50 characters)');
      return;
    }
    setIsGenerating(true);
    await new Promise(r => setTimeout(r, 800));
    try {
      const title = inputTitle.trim() || 'Untitled Quiz Set';
      const set = generateQuizSet(inputText, title);
      saveQuizSet(set);
      setQuizSets(getQuizSets());
      setInputText('');
      setInputTitle('');
      showToast('✨ Quiz set generated successfully!');
      setPage('library');
    } catch (err) {
      showToast('Failed to generate quiz. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFileText = (text: string, filename: string) => {
    setInputText(text);
    setInputTitle(filename);
    showToast('✓ File analyzed! Review and click Generate.');
  };

  const handleStartQuiz = (set: QuizSet, mode: QuizMode) => {
    setActiveSet(set);
    setActiveMode(mode);
    setPage('quiz');
  };

  const handleQuizComplete = (correct: number, total: number) => {
    const newStreak = updateStreak(correct, total);
    setStreak(newStreak);
    if (activeSet) {
      saveResult({ quizSetId: activeSet.id, mode: activeMode, score: correct, total, date: Date.now() });
    }
    showToast(`🎉 ${correct}/${total} correct! Streak: ${newStreak.currentStreak} days`);
  };

  const handleDelete = (id: string) => {
    deleteQuizSet(id);
    setQuizSets(getQuizSets());
    setShowDeleteConfirm(null);
    showToast('Quiz set deleted');
  };

  const getModeCount = (set: QuizSet, mode: QuizMode): number => {
    switch (mode) {
      case 'flashcard': return set.flashcards.length;
      case 'multiple-choice': return set.multipleChoice.length;
      case 'true-false': return set.trueFalse.length;
      case 'fill-blank': return set.fillBlank.length;
      case 'matching': return set.matching.length;
      case 'rapid-fire': return set.multipleChoice.length;
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white font-['Inter',sans-serif]">
      {/* Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-violet-600/10 blur-3xl" />
        <div className="absolute top-1/3 -right-20 w-80 h-80 rounded-full bg-blue-600/10 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 w-72 h-72 rounded-full bg-teal-600/8 blur-3xl" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDMpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-40" />
      </div>

      {/* Toast */}
      {toast && (
        <div className="fixed top-4 right-4 z-50 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl px-5 py-3 text-sm text-white shadow-2xl animate-slide-in">
          {toast}
        </div>
      )}

      {/* Header */}
      <header className="relative z-10 border-b border-white/10 bg-black/20 backdrop-blur-xl sticky top-0">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-blue-600 flex items-center justify-center shadow-lg shadow-violet-500/30">
              <Zap size={18} className="text-white fill-white" />
            </div>
            <div>
              <div className="font-bold text-lg font-['Space_Grotesk',sans-serif] leading-none bg-gradient-to-r from-violet-300 to-blue-300 bg-clip-text text-transparent">
                Flash Genius
              </div>
              <div className="text-[10px] text-gray-500 leading-none">by Shaikh Brothers</div>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-1">
            {([['home', 'Home', <Home size={15} />], ['create', 'Create', <Plus size={15} />], ['library', 'Library', <BookOpen size={15} />], ['stats', 'Stats', <BarChart3 size={15} />]] as [Page, string, React.ReactNode][]).map(([p, label, icon]) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-medium transition-all ${page === p ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
              >
                {icon} {label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-orange-500/10 border border-orange-500/30 rounded-xl px-3 py-1.5">
              <Flame size={14} className="text-orange-400" />
              <span className="text-sm font-bold text-orange-300">{streak.currentStreak}</span>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        <div className="md:hidden flex border-t border-white/5 bg-black/10">
          {([['home', <Home size={15} />, 'Home'], ['create', <Plus size={15} />, 'Create'], ['library', <BookOpen size={15} />, 'Library'], ['stats', <BarChart3 size={15} />, 'Stats']] as [Page, React.ReactNode, string][]).map(([p, icon, label]) => (
            <button key={p} onClick={() => setPage(p)} className={`flex-1 flex flex-col items-center gap-0.5 py-2 text-[10px] font-medium transition-all ${page === p ? 'text-violet-400' : 'text-gray-500'}`}>
              {icon}{label}
            </button>
          ))}
        </div>
      </header>

      <main className="relative z-10 max-w-5xl mx-auto px-4 py-6 pb-20">

        {/* ═══ HOME PAGE ═══ */}
        {page === 'home' && (
          <div className="flex flex-col gap-8">
            {/* Hero */}
            <div className="text-center py-8">
              <div className="inline-flex items-center gap-2 bg-violet-500/10 border border-violet-500/30 rounded-full px-4 py-1.5 text-xs text-violet-300 mb-6">
                <Star size={12} className="fill-violet-400 text-violet-400" />
                AI-Powered Study Tool • Created by Shaikh Brothers
              </div>
              <h1 className="text-4xl md:text-6xl font-black font-['Space_Grotesk',sans-serif] mb-4 leading-none">
                <span className="bg-gradient-to-r from-white via-violet-200 to-blue-300 bg-clip-text text-transparent">
                  Learn Smarter,
                </span>
                <br />
                <span className="bg-gradient-to-r from-violet-400 to-blue-400 bg-clip-text text-transparent">
                  Not Harder
                </span>
              </h1>
              <p className="text-gray-400 text-lg max-w-xl mx-auto leading-relaxed mb-8">
                Transform any PDF, document, or text into powerful flashcards and quizzes in seconds. Track your progress with streak-based learning.
              </p>
              <div className="flex gap-3 justify-center flex-wrap">
                <button onClick={() => setPage('create')} className="btn-primary flex items-center gap-2 text-base px-6 py-3">
                  <Plus size={18} /> Create Quiz Set
                </button>
                <button onClick={() => setPage('library')} className="btn-secondary flex items-center gap-2 text-base px-6 py-3">
                  <BookOpen size={18} /> My Library
                </button>
              </div>
            </div>

            {/* Streak */}
            <div>
              <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-widest mb-3">Your Progress</h2>
              <StreakBadge streak={streak} />
            </div>

            {/* Ad */}
            <NativeBannerAd />

            {/* Features */}
            <div>
              <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-widest mb-4">Study Modes</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {(Object.entries(MODE_INFO) as [QuizMode, typeof MODE_INFO[QuizMode]][]).map(([mode, info]) => (
                  <div key={mode} className="rounded-2xl bg-white/5 border border-white/10 p-4 hover:bg-white/8 transition-all group">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${info.color} flex items-center justify-center mb-3 shadow-lg group-hover:scale-110 transition-transform`}>
                      <span className="text-white">{info.icon}</span>
                    </div>
                    <div className="font-semibold text-white text-sm mb-1">{info.label}</div>
                    <div className="text-gray-500 text-xs">{info.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent */}
            {quizSets.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-widest">Recent Sets</h2>
                  <button onClick={() => setPage('library')} className="text-xs text-violet-400 hover:text-violet-300 flex items-center gap-1">
                    View all <ChevronRight size={12} />
                  </button>
                </div>
                <div className="grid gap-3">
                  {quizSets.slice(0, 3).map(set => (
                    <div key={set.id} className="rounded-2xl bg-white/5 border border-white/10 p-4 flex items-center justify-between hover:bg-white/8 transition-all">
                      <div>
                        <div className="font-semibold text-white">{set.title}</div>
                        <div className="text-xs text-gray-500 mt-0.5">
                          {set.flashcards.length} cards • {set.multipleChoice.length} MC • {new Date(set.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                      <button
                        onClick={() => { setActiveSet(set); setPage('library'); }}
                        className="text-violet-400 hover:text-violet-300 p-2 rounded-xl hover:bg-violet-500/10 transition-all"
                      >
                        <Play size={18} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ═══ CREATE PAGE ═══ */}
        {page === 'create' && (
          <div className="flex flex-col gap-6 max-w-2xl mx-auto">
            <div>
              <h1 className="text-2xl font-bold text-white mb-1">Create Quiz Set</h1>
              <p className="text-gray-400 text-sm">Paste text or upload a file to generate your quiz</p>
            </div>

            {/* Title */}
            <div>
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-2 block">Quiz Title</label>
              <input
                type="text"
                placeholder="e.g. Biology Chapter 5"
                value={inputTitle}
                onChange={e => setInputTitle(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-violet-500/60 transition-colors"
              />
            </div>

            {/* Input Tabs */}
            <div>
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setInputTab('text')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${inputTab === 'text' ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' : 'bg-white/5 text-gray-400 border border-white/10 hover:border-white/20'}`}
                >
                  <AlignLeft size={14} /> Paste Text
                </button>
                <button
                  onClick={() => setInputTab('file')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${inputTab === 'file' ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' : 'bg-white/5 text-gray-400 border border-white/10 hover:border-white/20'}`}
                >
                  <Upload size={14} /> Upload File
                </button>
              </div>

              {inputTab === 'text' ? (
                <div>
                  <textarea
                    placeholder="Paste your text, notes, or content here... (minimum 50 characters)&#10;&#10;The more detailed your text, the better your quiz will be!"
                    value={inputText}
                    onChange={e => setInputText(e.target.value)}
                    rows={12}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 text-white placeholder-gray-600 focus:outline-none focus:border-violet-500/60 transition-colors resize-none leading-relaxed"
                  />
                  <div className="flex justify-between mt-2">
                    <span className={`text-xs ${inputText.length < 50 ? 'text-red-400' : 'text-emerald-400'}`}>
                      {inputText.length} characters {inputText.length < 50 ? `(need ${50 - inputText.length} more)` : '✓'}
                    </span>
                    {inputText && (
                      <button onClick={() => setInputText('')} className="text-xs text-gray-500 hover:text-white transition-colors">
                        Clear
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <div>
                  <FileUploader onTextExtracted={handleFileText} />
                  {inputText && (
                    <div className="mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30">
                      <p className="text-emerald-300 text-sm font-medium">✓ File analyzed — {inputText.length.toLocaleString()} characters extracted</p>
                      <p className="text-emerald-400/70 text-xs mt-0.5">Ready to generate quiz set</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Supported formats */}
            <div className="flex flex-wrap gap-2">
              {[
                { ext: 'PDF', color: 'text-red-400 bg-red-500/10 border-red-500/20' },
                { ext: 'DOCX', color: 'text-blue-400 bg-blue-500/10 border-blue-500/20' },
                { ext: 'TXT', color: 'text-green-400 bg-green-500/10 border-green-500/20' },
                { ext: 'MD', color: 'text-purple-400 bg-purple-500/10 border-purple-500/20' },
                { ext: 'CSV', color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' },
              ].map(f => (
                <span key={f.ext} className={`text-xs px-2.5 py-1 rounded-lg border font-mono font-bold ${f.color}`}>{f.ext}</span>
              ))}
            </div>

            <NativeBannerAd />

            {/* Generate */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating || inputText.trim().length < 50}
              className="btn-primary w-full py-4 text-base font-bold flex items-center justify-center gap-3 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {isGenerating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Generating Quiz Set...
                </>
              ) : (
                <>
                  <Zap size={20} className="fill-white" /> Generate Quiz Set
                </>
              )}
            </button>
          </div>
        )}

        {/* ═══ LIBRARY PAGE ═══ */}
        {page === 'library' && (
          <div className="flex flex-col gap-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white mb-1">My Library</h1>
                <p className="text-gray-400 text-sm">{quizSets.length} quiz set{quizSets.length !== 1 ? 's' : ''}</p>
              </div>
              <button onClick={() => setPage('create')} className="btn-primary flex items-center gap-2">
                <Plus size={16} /> New Set
              </button>
            </div>

            {quizSets.length === 0 ? (
              <div className="text-center py-16 flex flex-col items-center gap-4">
                <div className="w-20 h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                  <BookOpen size={32} className="text-gray-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">No quiz sets yet</h3>
                  <p className="text-gray-500 text-sm">Create your first quiz set to get started</p>
                </div>
                <button onClick={() => setPage('create')} className="btn-primary flex items-center gap-2">
                  <Plus size={16} /> Create First Set
                </button>
              </div>
            ) : (
              <div className="grid gap-4">
                {quizSets.map(set => (
                  <div key={set.id} className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden hover:border-white/20 transition-all">
                    <div className="p-5">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1 min-w-0 pr-3">
                          <h3 className="font-bold text-white text-lg leading-tight truncate">{set.title}</h3>
                          <p className="text-gray-500 text-xs mt-1 flex items-center gap-1.5">
                            <Clock size={11} /> {new Date(set.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </p>
                        </div>
                        <button
                          onClick={() => setShowDeleteConfirm(set.id)}
                          className="p-2 rounded-xl text-gray-600 hover:text-red-400 hover:bg-red-500/10 transition-all"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>

                      {/* Mode counts */}
                      <div className="flex flex-wrap gap-2 mb-4">
                        {(Object.keys(MODE_INFO) as QuizMode[]).map(mode => {
                          const count = getModeCount(set, mode);
                          if (count === 0) return null;
                          return (
                            <span key={mode} className="text-xs px-2 py-0.5 rounded-full bg-white/8 text-gray-400">
                              {MODE_INFO[mode].label}: {count}
                            </span>
                          );
                        })}
                      </div>

                      {/* Mode buttons */}
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {(Object.entries(MODE_INFO) as [QuizMode, typeof MODE_INFO[QuizMode]][]).map(([mode, info]) => {
                          const count = getModeCount(set, mode);
                          if (count === 0) return null;
                          return (
                            <button
                              key={mode}
                              onClick={() => handleStartQuiz(set, mode)}
                              className={`flex items-center gap-2 p-2.5 rounded-xl bg-gradient-to-r ${info.color} bg-opacity-20 text-white text-xs font-medium hover:opacity-90 transition-all group`}
                            >
                              <span className="opacity-80">{info.icon}</span>
                              <span>{info.label}</span>
                              <ChevronRight size={12} className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Delete confirm */}
                    {showDeleteConfirm === set.id && (
                      <div className="border-t border-red-500/20 bg-red-500/10 p-4 flex items-center justify-between">
                        <span className="text-sm text-red-300">Delete this quiz set?</span>
                        <div className="flex gap-2">
                          <button onClick={() => setShowDeleteConfirm(null)} className="px-3 py-1.5 rounded-lg bg-white/10 text-gray-300 text-sm hover:bg-white/15 transition-all">Cancel</button>
                          <button onClick={() => handleDelete(set.id)} className="px-3 py-1.5 rounded-lg bg-red-500/30 text-red-200 border border-red-500/40 text-sm hover:bg-red-500/50 transition-all">Delete</button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            <NativeBannerAd />
          </div>
        )}

        {/* ═══ QUIZ PAGE ═══ */}
        {page === 'quiz' && activeSet && (
          <div className="flex flex-col gap-6 max-w-2xl mx-auto">
            {/* Header */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setPage('library')}
                className="p-2 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 transition-all"
              >
                <X size={18} />
              </button>
              <div className="flex-1 min-w-0">
                <h2 className="font-bold text-white truncate">{activeSet.title}</h2>
                <p className="text-xs text-gray-500">{MODE_INFO[activeMode].label}</p>
              </div>
              <div className={`px-3 py-1.5 rounded-xl bg-gradient-to-r ${MODE_INFO[activeMode].color} text-white text-xs font-bold`}>
                {MODE_INFO[activeMode].icon}
              </div>
            </div>

            {/* Mode Selector */}
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              {(Object.entries(MODE_INFO) as [QuizMode, typeof MODE_INFO[QuizMode]][]).map(([mode, info]) => {
                const count = getModeCount(activeSet, mode);
                if (count === 0) return null;
                return (
                  <button
                    key={mode}
                    onClick={() => setActiveMode(mode)}
                    className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all ${activeMode === mode ? `bg-gradient-to-r ${info.color} text-white shadow-lg` : 'bg-white/5 border border-white/10 text-gray-400 hover:border-white/20'}`}
                  >
                    {info.icon} {info.label}
                  </button>
                );
              })}
            </div>

            {/* Quiz Content */}
            <div className="rounded-2xl bg-white/3 border border-white/10 p-6">
              {activeMode === 'flashcard' && (
                <FlashcardMode cards={activeSet.flashcards} onComplete={handleQuizComplete} />
              )}
              {activeMode === 'multiple-choice' && (
                <MultipleChoiceMode questions={activeSet.multipleChoice} onComplete={handleQuizComplete} />
              )}
              {activeMode === 'true-false' && (
                <TrueFalseMode questions={activeSet.trueFalse} onComplete={handleQuizComplete} />
              )}
              {activeMode === 'fill-blank' && (
                <FillBlankMode questions={activeSet.fillBlank} onComplete={handleQuizComplete} />
              )}
              {activeMode === 'matching' && (
                <MatchingMode pairs={activeSet.matching} onComplete={handleQuizComplete} />
              )}
              {activeMode === 'rapid-fire' && (
                <RapidFireMode questions={activeSet.multipleChoice} onComplete={handleQuizComplete} />
              )}
            </div>

            <NativeBannerAd />
          </div>
        )}

        {/* ═══ STATS PAGE ═══ */}
        {page === 'stats' && (
          <div className="flex flex-col gap-6">
            <div>
              <h1 className="text-2xl font-bold text-white mb-1">Statistics</h1>
              <p className="text-gray-400 text-sm">Track your learning journey</p>
            </div>

            <StreakBadge streak={streak} />

            {/* Detail Stats */}
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-2xl bg-white/5 border border-white/10 p-4">
                <div className="text-xs text-gray-500 mb-1">Total Sessions</div>
                <div className="text-3xl font-bold text-white">{streak.totalSessions}</div>
              </div>
              <div className="rounded-2xl bg-white/5 border border-white/10 p-4">
                <div className="text-xs text-gray-500 mb-1">Total Answered</div>
                <div className="text-3xl font-bold text-white">{streak.totalAnswered}</div>
              </div>
              <div className="rounded-2xl bg-white/5 border border-white/10 p-4">
                <div className="text-xs text-gray-500 mb-1">Correct Answers</div>
                <div className="text-3xl font-bold text-emerald-400">{streak.totalCorrect}</div>
              </div>
              <div className="rounded-2xl bg-white/5 border border-white/10 p-4">
                <div className="text-xs text-gray-500 mb-1">Quiz Sets</div>
                <div className="text-3xl font-bold text-violet-400">{quizSets.length}</div>
              </div>
            </div>

            {/* Accuracy Bar */}
            {streak.totalAnswered > 0 && (
              <div className="rounded-2xl bg-white/5 border border-white/10 p-5">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-sm font-semibold text-white">Overall Accuracy</span>
                  <span className="text-2xl font-bold text-white">
                    {Math.round((streak.totalCorrect / streak.totalAnswered) * 100)}%
                  </span>
                </div>
                <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-violet-500 to-emerald-500 rounded-full transition-all duration-1000"
                    style={{ width: `${(streak.totalCorrect / streak.totalAnswered) * 100}%` }}
                  />
                </div>
              </div>
            )}

            {/* Achievements */}
            <div>
              <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-widest mb-3">Achievements</h2>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: '🔥', title: 'Streak Starter', desc: '3+ day streak', achieved: streak.currentStreak >= 3 },
                  { icon: '⚡', title: 'Speed Demon', desc: 'Rapid Fire mode', achieved: streak.totalSessions > 0 },
                  { icon: '🎯', title: 'Accurate', desc: '80%+ accuracy', achieved: streak.totalAnswered > 0 && (streak.totalCorrect / streak.totalAnswered) >= 0.8 },
                  { icon: '📚', title: 'Bookworm', desc: '5+ quiz sets', achieved: quizSets.length >= 5 },
                  { icon: '🏆', title: 'Champion', desc: '7+ day streak', achieved: streak.longestStreak >= 7 },
                  { icon: '🌟', title: 'Scholar', desc: '100+ answered', achieved: streak.totalAnswered >= 100 },
                ].map(a => (
                  <div key={a.title} className={`rounded-2xl border p-4 flex items-center gap-3 transition-all ${a.achieved ? 'bg-gradient-to-br from-violet-500/20 to-blue-500/20 border-violet-500/40' : 'bg-white/3 border-white/10 opacity-40'}`}>
                    <span className="text-2xl">{a.icon}</span>
                    <div>
                      <div className="text-sm font-semibold text-white">{a.title}</div>
                      <div className="text-xs text-gray-500">{a.desc}</div>
                    </div>
                    {a.achieved && <Award size={14} className="text-yellow-400 ml-auto" />}
                  </div>
                ))}
              </div>
            </div>

            <NativeBannerAd />

            {/* About */}
            <div className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-blue-500/10 border border-violet-500/20 p-5 text-center">
              <div className="text-2xl mb-2">⚡</div>
              <div className="font-bold text-white mb-1">Flash Genius</div>
              <div className="text-xs text-gray-400">Created with ❤️ by <span className="text-violet-300 font-semibold">Shaikh Brothers</span></div>
              <div className="text-xs text-gray-600 mt-2">AI-powered flashcard & quiz generator</div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/10 py-6 text-center">
        <div className="text-xs text-gray-600">
          © 2024 <span className="text-gray-500 font-semibold">Flash Genius</span> by Shaikh Brothers • 
          <span className="ml-1">All rights reserved</span>
        </div>
      </footer>
    </div>
  );
}
