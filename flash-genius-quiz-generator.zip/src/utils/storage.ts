import { QuizSet, StreakData, QuizResult } from '../types';

const QUIZ_SETS_KEY = 'flashgenius_quiz_sets';
const STREAK_KEY = 'flashgenius_streak';
const RESULTS_KEY = 'flashgenius_results';

export function saveQuizSet(set: QuizSet): void {
  const sets = getQuizSets();
  const existing = sets.findIndex(s => s.id === set.id);
  if (existing >= 0) {
    sets[existing] = set;
  } else {
    sets.unshift(set);
  }
  localStorage.setItem(QUIZ_SETS_KEY, JSON.stringify(sets));
}

export function getQuizSets(): QuizSet[] {
  try {
    const data = localStorage.getItem(QUIZ_SETS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function deleteQuizSet(id: string): void {
  const sets = getQuizSets().filter(s => s.id !== id);
  localStorage.setItem(QUIZ_SETS_KEY, JSON.stringify(sets));
}

export function getStreak(): StreakData {
  try {
    const data = localStorage.getItem(STREAK_KEY);
    if (data) return JSON.parse(data);
  } catch {}
  return {
    currentStreak: 0,
    longestStreak: 0,
    lastStudyDate: '',
    totalSessions: 0,
    totalCorrect: 0,
    totalAnswered: 0,
    dailyGoal: 10,
    todayCount: 0,
  };
}

export function updateStreak(correct: number, total: number): StreakData {
  const streak = getStreak();
  const today = new Date().toDateString();
  const yesterday = new Date(Date.now() - 86400000).toDateString();

  if (streak.lastStudyDate === today) {
    streak.todayCount += total;
  } else if (streak.lastStudyDate === yesterday) {
    streak.currentStreak += 1;
    streak.todayCount = total;
  } else if (streak.lastStudyDate !== today) {
    streak.currentStreak = 1;
    streak.todayCount = total;
  }

  streak.longestStreak = Math.max(streak.longestStreak, streak.currentStreak);
  streak.lastStudyDate = today;
  streak.totalSessions += 1;
  streak.totalCorrect += correct;
  streak.totalAnswered += total;

  localStorage.setItem(STREAK_KEY, JSON.stringify(streak));
  return streak;
}

export function saveResult(result: QuizResult): void {
  const results = getResults();
  results.unshift(result);
  const trimmed = results.slice(0, 100);
  localStorage.setItem(RESULTS_KEY, JSON.stringify(trimmed));
}

export function getResults(): QuizResult[] {
  try {
    const data = localStorage.getItem(RESULTS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}
