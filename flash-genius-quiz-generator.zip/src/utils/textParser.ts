import { Flashcard, MultipleChoiceQuestion, TrueFalseQuestion, FillBlankQuestion, MatchingPair, QuizSet } from '../types';
import { v4 as uuidv4 } from 'uuid';

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function extractSentences(text: string): string[] {
  const cleaned = text
    .replace(/\s+/g, ' ')
    .replace(/[^\w\s.,!?;:()\-'"]/g, ' ')
    .trim();
  
  const sentences = cleaned
    .split(/(?<=[.!?])\s+/)
    .map(s => s.trim())
    .filter(s => s.length > 20 && s.split(' ').length >= 4);
  
  return sentences;
}

function extractKeyPhrases(text: string): { term: string; context: string }[] {
  const lines = text.split(/\n+/).map(l => l.trim()).filter(l => l.length > 5);
  const pairs: { term: string; context: string }[] = [];

  // Look for definition patterns
  const defPatterns = [
    /^([A-Z][^:.\n]{2,40}):\s+(.{20,})/,
    /^([A-Z][^.!\n]{2,40})\s+is\s+(.{15,}[.!])/i,
    /^([A-Z][^.!\n]{2,40})\s+refers to\s+(.{15,}[.!])/i,
    /^([A-Z][^.!\n]{2,40})\s+means?\s+(.{15,}[.!])/i,
    /^([A-Z][^.!\n]{2,40})\s+are\s+(.{15,}[.!])/i,
    /^([A-Z][^.!\n]{2,40})\s+can be\s+(.{15,}[.!])/i,
    /^([A-Z][^.!\n]{2,40})\s+defined as\s+(.{15,}[.!])/i,
  ];

  for (const line of lines) {
    for (const pattern of defPatterns) {
      const match = line.match(pattern);
      if (match && match[1].length < 60 && match[2].length > 10) {
        pairs.push({ term: match[1].trim(), context: match[2].trim() });
        break;
      }
    }
  }

  // Also extract noun phrases from sentences
  const sentences = extractSentences(text);
  for (const sentence of sentences.slice(0, 30)) {
    const words = sentence.split(' ');
    if (words.length >= 6) {
      // Find capitalized multi-word terms
      for (let i = 0; i < words.length - 1; i++) {
        if (/^[A-Z][a-z]+$/.test(words[i]) && /^[A-Z][a-z]+$/.test(words[i + 1])) {
          const term = `${words[i]} ${words[i + 1]}`;
          if (!pairs.find(p => p.term === term)) {
            pairs.push({ term, context: sentence });
          }
        }
      }
    }
  }

  return pairs.slice(0, 30);
}

function generateFlashcards(text: string): Flashcard[] {
  const flashcards: Flashcard[] = [];
  const sentences = extractSentences(text);
  const phrases = extractKeyPhrases(text);

  // From definition patterns
  for (const { term, context } of phrases.slice(0, 15)) {
    flashcards.push({
      id: uuidv4(),
      front: `What is ${term}?`,
      back: context.length > 200 ? context.slice(0, 200) + '...' : context,
    });
  }

  // From sentences - question style
  for (const sentence of sentences.slice(0, 20)) {
    const words = sentence.split(' ');
    if (words.length >= 8) {
      // Create a question by removing key part
      const midIdx = Math.floor(words.length / 2);
      const keyword = words.slice(midIdx - 1, midIdx + 2).join(' ');
      if (keyword.length > 3) {
        flashcards.push({
          id: uuidv4(),
          front: `Complete: "${sentence.replace(keyword, '______')}"`,
          back: keyword,
        });
      }
    }
    if (flashcards.length >= 20) break;
  }

  return flashcards.slice(0, 20);
}

function generateMultipleChoice(text: string): MultipleChoiceQuestion[] {
  const questions: MultipleChoiceQuestion[] = [];
  const sentences = extractSentences(text);
  const phrases = extractKeyPhrases(text);

  // From definition pairs
  for (const { term, context } of phrases.slice(0, 10)) {
    const wrongAnswers = phrases
      .filter(p => p.term !== term)
      .map(p => p.context.slice(0, 80) + (p.context.length > 80 ? '...' : ''))
      .slice(0, 3);

    if (wrongAnswers.length >= 3) {
      const correct = context.slice(0, 100) + (context.length > 100 ? '...' : '');
      const options = shuffle([correct, ...wrongAnswers]);
      questions.push({
        id: uuidv4(),
        question: `Which of the following best describes "${term}"?`,
        options,
        correctIndex: options.indexOf(correct),
        explanation: `${term} refers to: ${context}`,
      });
    }
  }

  // From sentences - fill keyword style
  for (const sentence of sentences.slice(0, 15)) {
    const words = sentence.split(' ').filter(w => w.length > 4);
    if (words.length < 5) continue;

    const targetIdx = Math.floor(words.length * 0.6);
    const target = words[targetIdx]?.replace(/[.,!?]/g, '');
    if (!target || target.length < 4) continue;

    const distractors: string[] = [];
    for (const other of sentences) {
      const otherWords = other.split(' ').filter(w => w.length > 4 && w !== target);
      if (otherWords.length > 0) {
        const d = otherWords[Math.floor(Math.random() * otherWords.length)]?.replace(/[.,!?]/g, '');
        if (d && d.length > 3 && !distractors.includes(d)) {
          distractors.push(d);
        }
      }
      if (distractors.length >= 3) break;
    }

    if (distractors.length >= 3) {
      const options = shuffle([target, ...distractors.slice(0, 3)]);
      questions.push({
        id: uuidv4(),
        question: sentence.replace(new RegExp(`\\b${target}\\b`), '________'),
        options,
        correctIndex: options.indexOf(target),
      });
    }

    if (questions.length >= 15) break;
  }

  return questions.slice(0, 15);
}

function generateTrueFalse(text: string): TrueFalseQuestion[] {
  const questions: TrueFalseQuestion[] = [];
  const sentences = extractSentences(text);
  void extractKeyPhrases(text); // reserved for future use

  // True statements from text
  for (const sentence of sentences.slice(0, 10)) {
    if (sentence.split(' ').length >= 6) {
      questions.push({
        id: uuidv4(),
        statement: sentence,
        isTrue: true,
        explanation: 'This statement is directly supported by the text.',
      });
    }
  }

  // False statements - modify true ones
  const modifiers = ['not ', 'never ', 'always ', 'only '];
  for (const sentence of sentences.slice(0, 8)) {
    const words = sentence.split(' ');
    if (words.length >= 5) {
      const mod = modifiers[Math.floor(Math.random() * modifiers.length)];
      const idx = Math.floor(words.length * 0.3);
      const falseSentence = [...words.slice(0, idx), mod + words[idx], ...words.slice(idx + 1)].join(' ');
      questions.push({
        id: uuidv4(),
        statement: falseSentence,
        isTrue: false,
        explanation: `The original text states: "${sentence}"`,
      });
    }
    if (questions.length >= 15) break;
  }

  return shuffle(questions).slice(0, 15);
}

function generateFillBlank(text: string): FillBlankQuestion[] {
  const questions: FillBlankQuestion[] = [];
  const sentences = extractSentences(text);

  for (const sentence of sentences.slice(0, 15)) {
    const words = sentence.split(' ');
    if (words.length < 6) continue;

    const blanks: { word: string; idx: number }[] = [];
    const count = words.length > 12 ? 2 : 1;

    for (let i = 0; i < count; i++) {
      let attempts = 0;
      while (attempts < 10) {
        const idx = Math.floor(Math.random() * (words.length - 2)) + 1;
        const word = words[idx].replace(/[.,!?;:]/g, '');
        if (word.length >= 4 && !blanks.find(b => b.idx === idx)) {
          blanks.push({ word, idx });
          break;
        }
        attempts++;
      }
    }

    if (blanks.length === 0) continue;

    let masked = sentence;
    const blankWords: string[] = [];
    for (const { word } of blanks) {
      masked = masked.replace(new RegExp(`\\b${word}\\b`), `______`);
      blankWords.push(word);
    }

    questions.push({
      id: uuidv4(),
      sentence: masked,
      blanks: blankWords,
      hint: `Fill in ${blankWords.length} word${blankWords.length > 1 ? 's' : ''}`,
    });
  }

  return questions.slice(0, 12);
}

function generateMatching(text: string): MatchingPair[] {
  const phrases = extractKeyPhrases(text);
  const pairs: MatchingPair[] = [];

  for (const { term, context } of phrases.slice(0, 10)) {
    pairs.push({
      id: uuidv4(),
      term,
      definition: context.slice(0, 100) + (context.length > 100 ? '...' : ''),
    });
  }

  // If not enough from patterns, extract from sentences
  if (pairs.length < 6) {
    const sentences = extractSentences(text);
    for (const s of sentences.slice(0, 10)) {
      const words = s.split(' ');
      if (words.length >= 8) {
        const term = words.slice(0, 3).join(' ');
        const def = words.slice(3).join(' ');
        pairs.push({ id: uuidv4(), term, definition: def });
      }
      if (pairs.length >= 10) break;
    }
  }

  return pairs.slice(0, 10);
}

export function generateQuizSet(text: string, title: string = 'My Quiz Set'): QuizSet {
  return {
    id: uuidv4(),
    title,
    description: `Generated from ${text.slice(0, 60)}...`,
    createdAt: Date.now(),
    flashcards: generateFlashcards(text),
    multipleChoice: generateMultipleChoice(text),
    trueFalse: generateTrueFalse(text),
    fillBlank: generateFillBlank(text),
    matching: generateMatching(text),
    sourceText: text.slice(0, 500),
  };
}

export function readTextFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => resolve(e.target?.result as string);
    reader.onerror = reject;
    reader.readAsText(file);
  });
}
